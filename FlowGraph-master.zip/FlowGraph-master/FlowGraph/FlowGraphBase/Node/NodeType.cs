﻿namespace FlowGraphBase.Node
{
    /// <summary>
    /// 
    /// </summary>
    public enum NodeType
    {
        Action,
        Event,
        Variable
    }
}
