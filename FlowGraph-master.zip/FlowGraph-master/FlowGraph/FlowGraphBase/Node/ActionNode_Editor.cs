﻿namespace FlowGraphBase.Node
{
    /// <summary>
    /// 
    /// </summary>
    public partial class ActionNode
    {
        /// <summary>
        /// 
        /// </summary>
        public override NodeType NodeType => NodeType.Action;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="seqMgr_"></param>
        public ActionNode()
        {
        }
    }
}
