﻿using System.Windows.Controls;

namespace FlowSimulator.UI
{
    /// <summary>
    /// Interaction logic for DebugControl.xaml
    /// </summary>
    public partial class DebugControl : UserControl
    {
        /// <summary>
        /// 
        /// </summary>
        public DebugControl()
        {
            InitializeComponent();
        }
    }
}
