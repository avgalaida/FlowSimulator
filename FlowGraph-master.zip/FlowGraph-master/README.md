# FlowGraph
Flow Graph is a visual scripting system that can be used to built simple and complex logic with only a few clicks. With the editor the users can easily prototype sets of test and sequences of actions.
This is completely inspired by the Unreal Engine Blueprint.

![Flow simulator screenshot](/flow-simulator.jpg)
